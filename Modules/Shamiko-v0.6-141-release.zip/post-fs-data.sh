MODDIR=${0%/*}

if [[ "$(magisk -v)" != *"-alpha:MAGISK:"? ]]; then
  touch "$MODDIR/disable"
elif [ "$(magisk -V)" -lt 25206 ]; then
  touch "$MODDIR/disable"
fi
