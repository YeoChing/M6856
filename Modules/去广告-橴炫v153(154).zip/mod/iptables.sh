list="
#谷歌和doubleclick广告
ad-emea.doubleclick.net
static.doubleclick.net
www.googleadservices.com
googleadservices.com
ad.doubleclick.net
doubleclick.net
302br.net
#admaster
admaster.com.cn
admaster.com
admaster.cn
#其他
sprout-ad.com
ads.pointroll.com
ads.tremorhub.com
ad.corp.appnexus.com
c.admaster.com.cn
api.pushwoosh.com
net.zooplus.de
erebor.douban.com
adm.adk2.co
daraz.com
"
local IFS=$'\n'
for i in $list ;do
#排除注释
test "$(echo $i | grep -w '^#')" != "" && continue
#禁用网址和子域名
iptables -A OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
#iptables -D OUTPUT -m string --string "$i" --algo bm --to 65535 -j DROP
done 

