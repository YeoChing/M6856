#!/system/bin/sh
# 请不要硬编码 /magisk/modname/... ; 请使用 $MODDIR/...
# 这将使你的脚本更加兼容，即使Magisk在未来改变了它的挂载点
MODDIR=${0%/*}
mount --bind $MODDIR/my_product/etc/permissions/ /my_product/etc/permissions/
mount --bind $MODDIR/my_product/etc/extension/ /my_product/etc/extension/
mount --bind $MODDIR/my_bigball/battery/sys_deviceidle_whitelist.xml /my_bigball/battery/sys_deviceidle_whitelist.xml
mount --bind $MODDIR/my_product/etc/extension/ /my_product/etc/extension/
mount --bind $MODDIR/my_bigball/default-permissions/default-permissions-google.xml /my_bigball/default-permissions/default-permissions-google.xml
mount --bind $MODDIR/my_product/etc/vibrator/ /my_product/etc/vibrator/
mount --bind $MODDIR/my_product/etc/vibrator_service_config/ /my_product/etc/vibrator_service_config/
mount --bind $MODDIR/my_region/etc/extension/ /my_region/etc/extension/
# 这个脚本将以 post-fs-data 模式执行(系统启动前执行)
# 更多信息请访问 Magisk 主题
