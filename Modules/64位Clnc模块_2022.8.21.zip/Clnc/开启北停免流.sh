cd /data/Clnc
sed -i "/modeName=/cmodeName='/免流模式/北停'" /data/Clnc/config.ini
sleep 3
"${0%/*}"/Core/CuteBi start