cd /data/Clnc
sed -i "/modeName=/cmodeName='/免流模式/百度'" /data/Clnc/config.ini
sleep 3
"${0%/*}"/Core/CuteBi start